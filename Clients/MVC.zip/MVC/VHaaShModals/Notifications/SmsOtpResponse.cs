﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VHaaShAPIModals.Notifications
{
    public class OtpResponse
    {
        public string Status { get; set; }
        public string Details { get; set; }
    }
}
